package com.example.springBatch.domain;

import lombok.Data;

@Data
public class BuUser {
    private String userName;
    private String sex;
    private String age;
    private String address;
}

